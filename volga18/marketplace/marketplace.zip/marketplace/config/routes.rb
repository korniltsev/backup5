Rails.application.routes.draw do

  get 'login/login'

  post 'login' => 'login#login'

  post 'registration' => 'registration#registration'

  get 'registration' => 'registration#index'

  get 'login' => 'login#index'

  post 'profile' => 'profile#promo'

  post 'profile/change' => 'profile#change'

  get 'profile/deleteitem/:id' => 'profile#delete_item', :constraints => { :id => /\d*/ }

  get 'profile' => 'profile#index'

  get 'sell' => 'sell#index'

  post 'sell' => 'sell#add'

  get 'item/:id' => 'item#index', :constraints => { :id => /\d*/ }

  post 'item/:id' => 'item#buy', :constraints => { :id => /\d*/ }

  get 'transaction' => 'transaction#index'

  post 'transaction' => 'transaction#transfer'

  get '/' => 'latest#index'

  get 'api/getlatest/' => 'api#get_latest'

  get 'api/getnewusers/' => 'api#get_new_users'

  get 'api/getpromo/' => 'api#get_promo'

  get 'topup' => 'topup#index'

  post 'topup' => 'topup#apply_promo'

  post 'transaction' => 'transaction#transfer'

  get 'file/:id' => 'file#index', :constraints => { :id => /\d*/ }

  get 'user/:id' => 'user#index', :constraints => { :id => /\d*/ }

  get 'registration' => 'login#registration'

  get 'logout' => 'logout#index'
  
  match '*path', via: :all, to: redirect('/404')
end
