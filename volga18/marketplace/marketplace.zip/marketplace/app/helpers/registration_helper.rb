module RegistrationHelper
     include Constants


     def is_dev(username)
          return username.include? DEV_PREFIX
     end
	
     def set_balance(username)
          if(is_dev(username))
               unless params[:value].nil?
                    return params[:value]
               end
          end
          return 5
     end
end
