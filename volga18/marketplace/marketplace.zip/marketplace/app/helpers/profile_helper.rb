module ProfileHelper


	def delete_item_by_id(id)
          item = Item.find_by(id: id)
          item.destroy unless item.nil?
     end

     def get_file_name(text)
          index1 = 'filename="'
          index2 = '"'
          text[/#{index1}(.*?)#{index2}/m, 1]
     end

end
