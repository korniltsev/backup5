module Constants
     
  PROMO = ["marketplacerus", "marketplacechristmas", "marketplacevalentine" ]

  PROMO_WITH_KEYS = {"marketplacerus" => 3 ,"marketplacechristmas" => 2, "marketplacevalentine" => 1}
  
  PREVIEW_PATH = "/uploads/preview/"

  DEV_PREFIX = "dev_marketplace_"
  
end