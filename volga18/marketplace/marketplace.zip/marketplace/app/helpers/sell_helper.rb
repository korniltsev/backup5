module SellHelper

     include Constants 

	def upload_preview(dir, file)
          file_name = file.original_filename
          file_name = Time.now.nsec.to_s + "_" + file_name
          Dir.mkdir(dir) unless File.exists?(dir)
          path = dir + file_name
          File.open(path, "wb") { |f| f.write(file.tempfile.read) } 
          return PREVIEW_PATH + file_name
	end



     def upload_to(dir, file)
          file_name = get_file_name(file.headers)
          Dir.mkdir(dir) unless File.exists?(dir)
          path = dir + file_name
          File.open(path, "wb") { |f| f.write(file.tempfile.read) } 
          return path
     end




     def get_file_name(text)
          index1 = 'filename="'
          index2 = '"'
          text[/#{index1}(.*?)#{index2}/m, 1]
     end

end
