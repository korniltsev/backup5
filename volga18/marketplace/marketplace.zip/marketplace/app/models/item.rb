class Item < ApplicationRecord
end
