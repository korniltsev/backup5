class TopupController < ApplicationController

before_action :user_is_logged_in

include Constants

  def index
    @user = User.find_by(username: session[:username])
    render "topup/index" 
  end

  def apply_promo
    @user = User.find_by(username: session[:username])
    if params[:promocode].present? 
      code = params[:promocode]
      begin
        value = PROMO_WITH_KEYS[code]
        @user.balance = @user.balance + value
        @user.save!
      rescue Exception => e
        @error = e
      end

    end
    render "topup/index" 
  end

  private

    def user_is_logged_in
    	if session[:username].nil?
    	   redirect_to "/login"
    end
  end
end
