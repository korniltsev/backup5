require 'fileutils'

class ItemController < ApplicationController
  
  before_action :user_is_logged_in


  def index
    @user = User.find_by(username: session[:username])
    begin
        @item = Item.find(params[:id])
    rescue Exception => e
        @error = "Error, item not found"
    end
    if @error 
      redirect_to "/"
    else
        @owner = User.find_by(id: @item.owner)
        render "item/index" 
    end
  end

  def buy 
    @user = User.find_by(username: session[:username])
    begin
      @item = Item.find(params[:id])
    rescue Exception => e
      @error = "Error, item not found"
    end
    if @error 
      redirect_to "/"
    else
        if @item.price<=@user.balance
          @user.balance = @user.balance-@item.price
          @user.save!
          @success = true
        elsif @item.owner == @user.id
          @success = true
        else
          @error = "Not enough money!"
        end
        @owner = User.find_by(id: @item.owner)
        render "item/index" 
    end
  end

  private
  	
    def user_is_logged_in
    	if !session[:username]
    	   redirect_to "/login"
    end
    
  end
  
end
