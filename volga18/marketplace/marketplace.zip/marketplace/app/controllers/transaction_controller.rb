class TransactionController < ApplicationController

before_action :user_is_logged_in

    
  def index
    @user = User.find_by(username: session[:username])
    render "transaction/index"    
  end

  def transfer
    user_from = User.find_by(username: session[:username])
    username = params[:username]
    value = params[:value]
    user_to = User.find_by(username: username)
    if(user_from.balance >= value.to_i and !user_to.nil?)
        user_from.balance = user_from.balance - value.to_i
        user_to.balance = user_to.balance + value.to_i
        user_from.save!
        user_to.save!

    end
    ""
  end

  private

  def user_is_logged_in
  	if session[:username].nil?
  	   redirect_to "/login"
  end
  
  end
end
