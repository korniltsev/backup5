require 'fileutils'

class UserController < ApplicationController
  
  before_action :user_is_logged_in

  def index
    @user = User.find_by(username: session[:username])
    begin
        @owner = User.find(params[:id])
    rescue Exception => e
        @error = "Error"
    end
    if @error 
      redirect_to "/latest"
    else
        @owner = User.find_by(id: params[:id])
        @items = Item.where(owner: @owner.id).last(4).reverse
        render "user/index" 
    end
  end

 private
  def user_is_logged_in
  	if !session[:username]
  	   redirect_to "/login"
  end
 end
  
end
