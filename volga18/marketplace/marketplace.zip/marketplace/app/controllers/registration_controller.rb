class RegistrationController < ApplicationController

before_action :user_is_logged_in

include RegistrationHelper

  def index
      render "registration/index"  
  end

  def registration
    unless (params[:username].nil? && params[:email].nil?)
        user = User.find_by(username: params[:username])
        unless user.nil? 
            @error = "User already exists"
        else
          user = User.new
          user.username = params[:username]
          user.email = params[:email]
          user.password = params[:username]
          user.balance = set_balance(params[:username])
          begin
              user.save!
              session[:username] = user.username
          rescue Exception => e
              @error = "Error"
          end
        end
    else
      @error = "Required parameter missing"
    end

    unless session[:username].nil?
      redirect_to "/"
    else
      render "registration/index" 
    end
     
  end

  private

  def user_is_logged_in
  	if session[:username]
  	   redirect_to "/"
  end
  
  end
end
