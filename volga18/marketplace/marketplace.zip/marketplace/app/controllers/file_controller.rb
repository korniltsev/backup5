require 'fileutils'

class FileController < ApplicationController
  
  before_action :user_is_logged_in

  def index
    @user = User.find_by(username: session[:username])
    begin
        @item = Item.find(params[:id])
    rescue Exception => e
        @error = "File not found"
    end
    if @error 
      redirect_to "/profile"
    else
      send_file(@item.path)
    end
  end

 private
  	
  def user_is_logged_in
  	if !session[:username]
  	   redirect_to "/login"
  end
  
  end
  
end
