require 'fileutils'

class LatestController < ApplicationController
  
  before_action :user_is_logged_in

  def index
    @user = User.find_by(username: session[:username])
    @items = Item.last(8).reverse
    render "latest/index" 
  end

 private
  def user_is_logged_in
  	if !session[:username]
  	   redirect_to "/login"
  end
 end
  
end
