require 'fileutils'

class SellController < ApplicationController
  
  include SellHelper

  before_action :user_is_logged_in


  def index
  	@user = User.find_by(username: session[:username])
    render "sell/index" 
  end

  def add
  	@user = User.find_by(username: session[:username])
    if(params[:price].present? & params[:description].present? & params[:item].present? & params[:name].present?)
	    begin
         dir = Dir.pwd + "/files/" + session[:username] + "/" 
         file_path_item = upload_to(dir, params[:item])
       rescue Exception => e
         @error = e
       end
       
       if(params[:preview].present?)
        begin
          dir = Dir.pwd + "/public/uploads/preview/"
          file_path_preview = upload_preview(dir, params[:preview])
        rescue Exception => e
          @error = e
        end
       end
   	   item = Item.new
  	   item.name = params[:name]
  	   item.description = params[:description]
 	     item.path = file_path_item
 	     item.preview = file_path_preview
 	     item.price = params[:price]
 	     item.owner = @user.id
      begin
        item.save!
    	rescue Exception => e
       @error = "Error"
    	end
    else 
      @error = "Please, complete all of fields!"
    end
   render "sell/index"
  end

 private


  	
  def user_is_logged_in
  	if !session[:username]
  	   redirect_to "/login"
  end
  
  end
  
end
