class ApiController < ActionController::Base
	skip_before_action :verify_authenticity_token

	include Constants

	def get_latest
		items = Item.last(10).reverse
		render :json =>  {:items => items}
	end


	def get_new_users
		users = User.last(3).reverse
		render :json =>  {:user => users}
	end

	def get_promo
		render :json =>  {:promo => PROMO}
	end
end
