class LoginController < ApplicationController

before_action :user_is_logged_in

  def login
  	unless (params[:username].nil? && params[:password].nil?)
  			user = User.find_by(username: params[:username])
  			unless user.nil? 
  					if(user.password == params[:password])
  							session[:username] = user.username
  							redirect_to "/profile" and return
  					end
  					@error = "Pasword doesn't match"
  			else
  					@error = "User not found"
  			end
    	  else
  		@error = "Required parameter missing"
  	end
  	render "login/index"		
  end

  def index
      render "login/index"  
  end

  private

  def user_is_logged_in
  	if session[:username]
  	   redirect_to "/"
  end
  
  end
end
