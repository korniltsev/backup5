class LogoutController < ActionController::Base
	skip_before_action :verify_authenticity_token

	def index
		reset_session
		redirect_to "/login"
	end
end
