class ProfileController < ApplicationController

before_action :user_is_logged_in

  include ProfileHelper

  def index
    @user = User.find_by(username: session[:username])
    @items = Item.where(owner: @user.id)
    render "profile/index"    
  end


  def delete_item
     @user = User.find_by(username: session[:username]) 
     unless params[:id].nil?
        id = params[:id]
        delete_item_by_id(id)
     end

     redirect_to "/profile"
  end

  def change
      @user = User.find_by(username: session[:username]) 
      unless params[:email].nil? and params[:password].nil?
          @user.email = params[:email]
          @user.password = params[:password]
          @user.save!
      end

      redirect_to "/profile"
  end


  private

  def user_is_logged_in
  	if session[:username].nil?
  	   redirect_to "/login"
  end
  
  end
end
